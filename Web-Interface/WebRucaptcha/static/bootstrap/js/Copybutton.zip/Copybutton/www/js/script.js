function copied(){
  var cop = "I dontknow";
  alert(cop);
}